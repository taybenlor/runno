#ifndef __wasm_basics___typedef_mode_t_h
#define __wasm_basics___typedef_mode_t_h

typedef unsigned mode_t;

#endif
