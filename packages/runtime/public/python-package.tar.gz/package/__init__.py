def say_hello():
    print("Hello from package")
