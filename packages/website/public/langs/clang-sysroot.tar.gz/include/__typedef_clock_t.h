#ifndef __wasm_basics___typedef_clock_t_h
#define __wasm_basics___typedef_clock_t_h

/* Define this as a 64-bit signed integer to avoid wraparounds. */
typedef long long clock_t;

#endif
